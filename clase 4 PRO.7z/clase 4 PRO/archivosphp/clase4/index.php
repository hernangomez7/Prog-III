<?php
//verifico si existe
if( file_exists("Datos/Datos.json") == false)
 {
	 echo "entro";
	 //creo directorio
	mkdir("Datos");
	//creo json
	$file = fopen("Datos/Datos.json","w");
 }else
 {
	$file = fopen("Datos/Datos.json","r");

 }

 fwrite($file, "texto ingresado");






?>