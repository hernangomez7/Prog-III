<?php
	class usuario
	{
		public $nombre;
		public $clave;
		function usuario($nombre,$clave)
		{
			this->$nombre = $nombre;
		}
	
	}
?>