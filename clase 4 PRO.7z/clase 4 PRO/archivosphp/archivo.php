<?php

//require usuario.php;

class usuario
{
	private $nombre;
	private $clave;
	
	public function __construct($nombre,$clave)
	{
		$this->nombre = $nombre;
		//$this->clave = $clave;
		var_dump( $this->nombre );
	}

	public function show()
	{
		echo $this->$nombre;
		//echo $this->$clave;
	}

}

//$persona = new usuario($_POST["nombre"]),$_POST["clave"]);
//$persona = new usuario("nombre","clave");
$persona = new usuario("nombre",2);
//$persona->agregar("nombre","clave");


$persona->show();


//armar una lista
//guardar lista en el json
//mostrar en el json, los datos
/*
var_dump( $_POST );
//en el post se guardara la clase, un array con todo

$persona["nombre"] = $_POST["nombre"];
$persona["clave"] = $_POST["clave"];



//verifico si existe
if( file_exists("Datos/Datos.json") == false)
 {
	 //creo directorio
	mkdir("Datos");
	//creo json
	$file = fopen("Datos/Datos.json","w");
 }else
 {
	$file = fopen("Datos/Datos.json","r");
 }

 fwrite($file, "texto");

*/



?>