if(localStorage)
{
    if(localStorage.token)
    {
        validateUser(localStorage.token);
    }
}

window.onload = function()
{
    //en un selector utilizado en jquery 
    $("#btnLogIn").click(function()
    {
        //ejecuta una funcion por clickear en btnLogIn
        login();
    }
    );

    //this.document.getElementById("btnLogIn").addEventListener otra manera de hacerlo
}

function validateUser(token)
{
    xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function()
    {
        if(this.readyState == 4)
        {
            if(this.status == 200)
            {
                //el OK es parte del server esto me lo diran
                if(xhr.responseText == "OK")
                {
                    window.location.replace("http://localhost:3000/admin.html")
                }
            }
            else
            {
                alert("no tiene permisos suficientes");
                window.location.replace("http://localhost:3000/accessdenied.html");
            }
        }
    }

    xhr.open("POST","http://localhost:3000/validate",false);
    xhr.setRequestHeader("authorization",token);
    xhr.send("");
}



var xhr;

function  login()
{
    //los atributos q deben viajar, bede tener los nombres correcto para el token
    var data = {
        "usuario": document.getElementById("name").value,
        "password": document.getElementById("pass").value
    }

    //uno de sus atributos son objetos (dta)
    var senddata = {"collection":"users","data":data};

    xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function(){
        if(this.readyState == 4)
        {
            if(this.status == 200)
            {
                //habria que validar storage
                localStorage.token = JSON.parse(xhr.responseText).token;
                //guardo token y lo redirecciono
                window.location.replace(xhr.getResponseHeader('redirect'));
            }
            if(this.status == 403)
            {
                window.location.replace("http://localhost:3000/accessdenied.html");
            }
        }
    };

    xhr.open("POST","http://localhost:3000/login",true);
    xhr.setRequestHeader("Content-Type","application/json");
    //xhr.send(senddata);
    xhr.send(JSON.stringify(senddata));
    


    
}