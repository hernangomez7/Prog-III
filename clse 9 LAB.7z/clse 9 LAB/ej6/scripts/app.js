window.addEventListener('load', inicializarEventos, false);

function inicializarEventos()
{
    document.getElementById('btnCargar').addEventListener('click',traerTexto, false);
}

function traerTexto()
{
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function()
    {
        if(this.readyState == 4 && this.status == 200)
        {
            var unaPersona = JSON.parse(this.responseText);
            document.getElementById('info').innerHTML = "Nombre:"+ unaPersona.nombre + " Edad:" + unaPersona.edad;
        }
    }

    xhr.open('GET', 'pagina.php', true);
    xhr.send();



}
