<?php

$persona = "{\"nombre\":\"juan\",\"edad\":\"32\"}";

echo $persona;


?>