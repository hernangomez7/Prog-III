window.addEventListener('load', inicializarEventos,false);

function inicializarEventos()
{
    document.getElementById('btnCrear').addEventListener('click', crearObjeto, false);

}

function crearObjeto()
{
    var cadena = '{"nombre":"juan","edad":23}';

    alert(cadena);
    //transformamos el string a json asi el obj persona tiene un json
    var persona = JSON.parse(cadena);

    console.log(persona);

    document.getElementById('info').innerHTML = persona.nombre;

    document.getElementById('info').innerHTML += " ";
    
    document.getElementById('info').innerHTML += persona.edad;

}