window.addEventListener('load', inicializarEventos, false);

function inicializarEventos()
{
    document.getElementById('btnCargar').addEventListener('click',CargarPersona, false);
}

function CargarPersona()
{
    var xhr = new XMLHttpRequest();

    xhr.onreadystatechange = function()
    {
        if(this.readyState == 4 && this.status == 200)
        {
            document.getElementById('info').innerHTML = this.responseText;
        }
    }

    var data = leerDatos();
    xhr.open('POST', 'pagina.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.send(data);

    //alert(encodeURIComponent('juan calos'));

}



function leerDatos()
{
    var cadena = '';
    var nombre = document.getElementById('txtNombre').value;
    var edad = document.getElementById('txtEdad').value;
    cadena += "nombre=" + encodeURIComponent(nombre) + '&edad=' +  encodeURIComponent(edad);
    return cadena;
}