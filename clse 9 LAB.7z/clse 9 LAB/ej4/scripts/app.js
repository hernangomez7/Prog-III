window.addEventListener('load', inicializarEventos, false);

function inicializarEventos()
{
    document.getElementById('frmPersona').addEventListener('submit',manejarSubmit, false);
}

function manejarSubmit(e)
{
    e.preventDefault();
    CargarPersona();
}

function CargarPersona()
{
    var xhr = new XMLHttpRequest();

    xhr.onreadystatechange = function()
    {
        document.getElementById('info').innerHTML = '<img src="./preloader.gif">';

        if(this.readyState == 4 )
        {
            if(this.status == 200)
            {
                document.getElementById('info').innerHTML = this.responseText;
            }
            else
            {
                document.getElementById('info').innerHTML = 'Error' + this.status + " ".statusText;
            }
        }
           
    }

    var frm = document.getElementById(frmPersona);
    var data = new FormData(frm);
    alert(data);
    //var data = leerDatos();
    xhr.open('POST', 'pagina.php', true);
    xhr.setRequestHeader('X-Requested-With','XMLHttpRequest');
    //xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded'); con este funciona
    xhr.send(data);


}



function leerDatos()
{
    var cadena = '';
    var nombre = document.getElementById('txtNombre').value;
    var edad = document.getElementById('txtEdad').value;
    cadena += "nombre=" + encodeURIComponent(nombre) + '&edad=' +  encodeURIComponent(edad);
    return cadena;
}
