window.addEventListener('load', inicializarEventos, false);

function inicializarEventos()
{
    document.getElementById('btnCargar').addEventListener('click',traerTexto, false);
}

//este implementara ajax
//se puede traer json,xml,texto pero se utiliza json a diferencia de xml porque es mal liviano asi q utilizamos json
function traerTexto()
{
    //intanciamos una var xml
    //generalmente de pone xhr
    var xhr = new XMLHttpRequest();
    //este cambiara en relacion a readystate
    xhr.onreadystatechange = function()
    {
        //el readystate es un valor numerico 0,1,2,3,4 cada vez q hacemos una peticion ajax cambiara el estado cinco vecez solo nos
        //importara el 4 cada numero indica un resultado siendo el 4 el ok
        //esta funcion sera llamada 5 veces, x cada vez q cambio el readystate entonces...
        //status si esta ok vendra 200+-
        //como el caso 404+- que es un error
        //407 falta de permiso a una pagina
        //500 error internal server
        //el statustext es una cadena que me describe el status segun el numero q llegue
        if(this.readyState == 4 && this.status == 200)
        {
            document.getElementById('info').innerHTML = this.responseText;
        }
    }

    //no estamos dentro de la funcion para llamarlo this
    //lo abrimos, si es true la llamada sera asincrona, las otras son usuario y pass en caso de q sea con un loggeo
    xhr.open('GET', './archivo.txt', true,);
    xhr.send();
    //es una buena practica es asignar obtener los datos y luego abrir el archivo o conexion y enviar los datos q sean necesarios
    //en este caso lo ponemos en un archivo

}