<?php

    include ".\\nexo.php";
    include ".\\Alumno.php";

    $nombre=$_POST['nombre'];
    $apellido=$_POST['apellido'];
    $email=$_POST['email'];

    $destino = "archivos/" . $_FILES["fotosubida"]["name"];

    $nuevoNombre = $email;

    if( file_exists(".//archivos/" . $nuevoNombre . "png") )
    {
        echo "existe";
        $destino = "backup/" . $_FILES["fotosubida"]["name"];

    }

    $elAlumno = new Alumno;
    $elAlumno->Constructor($nombre, $apellido, $email);

    echo $elAlumno->ToString();

    $elAlumno->GuardarAlumno();



/*
    $nombre=$_POST['nombre'];
    $codBarra=$_POST['codBarra'];

    $producto= new Producto;


    $producto->Constructor($nombre, $codBarra);




    $nuevoNombre = $producto->ToString();
    $destino = "archivos/" . $_FILES["fotosubida"]["name"];

    echo ".//archivos/" . $nuevoNombre . "png";

    if( file_exists(".//archivos/" . $nuevoNombre . "png") )
    {
        echo "existe";
        $destino = "backup/" . $_FILES["fotosubida"]["name"];

    }

    $producto->GuardarImg($nuevoNombre);

*/

?>