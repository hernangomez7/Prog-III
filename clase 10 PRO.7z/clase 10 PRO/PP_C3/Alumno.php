<?php

    class Alumno
    {
        public $nombre='';
        public $apellido='';
        public $email='';

        function Constructor($elNombre, $elApellido, $elEmail)
        {
            $this->nombre = $elNombre;
            $this->apellido = $elApellido;
            $this->email = $elEmail;
        }

        function ToString()
        {
            $myUsuario="$this->nombre"."  "."$this->apellido"."  "."$this->email";
            return $myUsuario;
        }
    


    public static function GuardarImg($nuevoNombre)
	{
        if (move_uploaded_file($_FILES["fotosubida"]["tmp_name"], "archivos/" . $nuevoNombre . ".png" )) {
            echo "<br/>El archivo ". basename( $_FILES["fotosubida"]["name"]). " ha sido subido exitosamente.";
        }
        else
        {
            echo "<br/>Lamentablemente ocurri&oacute; un error y no se pudo subir el archivo.";
        }        
    }

    public function GuardarAlumno()
	{
           
        if(!(file_exists (".\\Datos\\alumnos.txt")))
        {
            mkdir(".\\Datos");
            $fichero=fopen ( ".\\Datos\\alumnos.txt" , "w");
            fclose($fichero);
        }
        else
        {
            $contArchivo = file_get_contents(".\\Datos\\alumnos.txt");
        }

        //$aGuardar = $usuario->ToJson(".\\Datos\\alumnos.txt", $usuario);
        
        $aGuardar = $this->ToString();

        $aGuardar += ";";

        echo $aGuardar;

        $fichero=fopen ( ".\\Datos\\alumnos.txt" , "a");
        fwrite($fichero, $aGuardar );
        fclose($fichero);
    }

}
?>
