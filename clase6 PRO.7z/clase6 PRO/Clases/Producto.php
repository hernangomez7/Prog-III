<?php

    class Producto
    {
        public $nombre='';
        public $codBarra='';

        function Constructor($nombre, $codBarra)
        {
            $this->nombre=$nombre;
            $this->codBarra=$codBarra;
        }

        function ToString()
        {
            $myUsuario="$this->nombre"."  "."$this->codBarra";
            return $myUsuario;
        }
    


    public static function GuardarImg($nuevoNombre)
	{
        if (move_uploaded_file($_FILES["fotosubida"]["tmp_name"], "archivos/" . $nuevoNombre . ".png" )) {
            echo "<br/>El archivo ". basename( $_FILES["fotosubida"]["name"]). " ha sido subido exitosamente.";
        }
        else
        {
            echo "<br/>Lamentablemente ocurri&oacute; un error y no se pudo subir el archivo.";
        }        
    }
    

}
?>
