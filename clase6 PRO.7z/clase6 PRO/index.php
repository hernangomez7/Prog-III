<?php
include ".\\Clases\\Producto.php";

$nombre=$_POST['nombre'];
$codBarra=$_POST['codBarra'];

$producto= new Producto;


$producto->Constructor($nombre, $codBarra);

//echo $producto->ToString();



$nuevoNombre = $producto->ToString();
$destino = "archivos/" . $_FILES["fotosubida"]["name"];

//var_dump(pathinfo($destino));

echo ".//archivos/" . $nuevoNombre . "png";

if( file_exists(".//archivos/" . $nuevoNombre . "png") )
{
    echo "existe";
    $destino = "backup/" . $_FILES["fotosubida"]["name"];

}

$producto->GuardarImg($nuevoNombre);

/*
//MUEVO EL ARCHIVO DEL TEMPORAL AL DESTINO FINAL
if (move_uploaded_file($_FILES["fotosubida"]["tmp_name"], "archivos/" . $nuevoNombre .".png" )) {
    echo "<br/>El archivo ". basename( $_FILES["fotosubida"]["name"]). " ha sido subido exitosamente.";
} else {
    echo "<br/>Lamentablemente ocurri&oacute; un error y no se pudo subir el archivo.";
}

*/

?>