<?php
    include_once("./Entidades/Usuario.php"); 
    include_once("./Entidades/Archivo.php"); 
    include_once("./Entidades/Mensaje.php"); 
    include_once("./Entidades/MensajeFoto.php"); 

    $usuarioTXT = new Archivo("./Archivos/usuario.txt");
    $mensajesTXT = new Archivo("./Archivos/mensajes.txt");
    $mensajesFotoTXT = new Archivo("./Archivos/MensajeFoto.txt");

    if(isset($_POST["caso"]) && !empty($_POST["caso"]))
    {     
        $caso = $_POST["caso"];
        switch($caso)
        {

            case "crearUsuario": 
                $nombreObt = $_POST["Nombre"];
                $apellidoObt = $_POST["Apellido"];
                $emailObt = $_POST["Email"];
                $fotoObt = $_FILES["Foto"];

                $usuario = new Usuario($nombreObt, $apellidoObt, $emailObt, $fotoObt);
                $usuarioTXT->Cargar($usuario);

            break;

            case "cargarMensaje": 
                $remitenteobt = $_POST["Remitente"];
                $destinatarioObt = $_POST["Destinatario"];
                $mensajeObt = $_POST["Mensaje"];
                $fotoObt = $_FILES["Foto"];

                $mensaje = new Mensaje($remitenteobt, $destinatarioObt, $mensajeObt);
                $mensajeFoto = new FotoMensaje($fotoObt,$remitenteobt,$destinatarioObt);
                
                $mensajesTXT->Cargar($mensaje);
                $mensajesFotoTXT->Cargar($mensajeFoto);
                

            break;

            case "modificarUsuario": 
                $nombreObt = "";
                $apellidoObt = "";
                $emailObt = "";
                $fotoObt = "";

                if(isset($_POST["Nombre"]) && !empty($_POST["Nombre"]))
                {
                    $nombreObt = $_POST["Nombre"];
                }
                if(isset($_POST["Apellido"]) && !empty($_POST["Apellido"]))
                {
                    $apellidoObt = $_POST["Apellido"];
                }
                if(isset($_POST["Email"]) && !empty($_POST["Email"]))
                {
                    $emailObt = $_POST["Email"];
                }
                if(isset($_FILES["Foto"]) && !empty($_FILES["Foto"]))
                {
                    $fotoObt = $_FILES["Foto"];
                }
                if($emailObt != "")
                {
                    $suEmailString = $usuarioTXT->Consultar($emailObt,4,2);

                    if( !empty( $suEmailString ))
                    {
                        if($fotoObt != "")
                        {
                            $viejosDatosAlumno = explode("-", $suEmailString[0]);
                        
                            $hora = date("his");
                            $nombreBackUp = "./backUpFotos/$viejosDatosAlumno[0]$viejosDatosAlumno[1]$hora.png";
                            $destinoOrigen = "./Img";

                            $usuarioTXT->backUp($emailObt,2,4,$destinoOrigen,3,$nombreBackUp);

                            if( $nombreObt != "")
                            {
                                $nombreActual = $nombreObt;
                            }
                            else
                            {
                                $nombreActual = $viejosDatosAlumno[0];
                            }
                            if( $apellidoObt != "")
                            {
                                $apellidoActual = $apellidoObt;
                            }
                            else
                            {
                                $apellidoActual = $viejosDatosAlumno[1];
                            }
                            if( $fotoObt != "")
                            {
                                $fotoActual = $fotoObt;
                            }
                            else
                            {
                                $fotoActual = $viejosDatosAlumno[3];
                            }
                            
                            $usuarioNuevo =  new Usuario($nombreActual, $apellidoActual, $viejosDatosAlumno[2], $fotoActual);

                            $usuarioTXT->Modificar($emailObt, 2, 4,$usuarioNuevo);
            
            
                        }
                    }
                    else
                    {
                        echo "No se logro encontrar el usuario";
                    }
                }
                else
                {
                    echo "Ingrese un Email para poder modificar un usuario";
                }

            break;


            
            
        }
    }
    else if(isset($_GET["caso"]) && !empty($_GET["caso"]))
    {
        $caso = $_GET["caso"];
        switch($caso)
        {
            case "buscarUsuario":

                $apellidoObt = $_GET["Apellido"];
                $arrayExposure = $usuarioTXT->Consultar($apellidoObt,4,1);

                if(!empty($arrayExposure) )
                {
                    foreach( $arrayExposure as $arrayEchoes )
                    {
                        foreach( explode("-",$arrayEchoes) as $aMostrar )
                        {
                            echo $aMostrar;
                            echo " ";
                        }
                    }
                }
                else
                {
                    echo "No existe usuario con apellido ".$apellidoObt;
                }

            break;


        case "listarUsuarios": 

            echo "<br/> <h1>Listado de Usuarios</h1>";

            $arrayUsuariosAux = $usuarioTXT->fileToArray();
            
            $tabla = "<table border='1'>
                                <caption>Usiarios</caption>
                                <thead>
                                    <tr>
                                        <th>Nombre</th>
                                        <th>Apellido</th>
                                        <th>Email</th>
                                        <th>Foto</th>
                                    </tr>
                                </thead>
                                <tbody>";
            foreach($arrayUsuariosAux as $usuario)
            {
                if(!empty($usuario))
                {
                    $arrayUsuario = explode("-",$usuario);   
                    $tabla = $tabla."<tr>
                                    <td>$arrayUsuario[0]</td>
                                    <td>$arrayUsuario[1]</td>
                                    <td>$arrayUsuario[2]</td>
                                    <td><img style='width: 100px; height: 100px;' src='./Img/$arrayUsuario[2]_Foto.png'></td>
                                </tr>";
                }
            }

            $tabla = $tabla."</tbody>
                        </table>";
            echo $tabla;
            break;

            

            case "mensajesRecibidos":

            $emailObt = $_GET["Email"];
            $arrayExposure = $mensajesTXT->Consultar($emailObt,3,1);

            if(!empty($arrayExposure) )
            {
                foreach( $arrayExposure as $arrayEchoes )
                {
                    $arrayExpo = array();
                    foreach( explode("-",$arrayEchoes) as $aMostrar )
                    {

                        $arrayExpo[] = $aMostrar;
                    }
                    echo "Remitente:".$arrayExpo[0];
                    echo "<br>";
                    echo "Destinatario:".$arrayExpo[1];
                    echo "<br>";
                    echo "Mensaje:".$arrayExpo[2];
                }
            }
            else
            {
                echo "el usuario ".$emailObt." no recibio mensajes";
            }

            break;

            case "mensajesEnviados":

            $emailObt = $_GET["Email"];
            $arrayExposure = $mensajesTXT->Consultar($emailObt,3,0);

            if(!empty($arrayExposure) )
            {
                foreach( $arrayExposure as $arrayEchoes )
                {
                    $arrayExpo = array();
                    foreach( explode("-",$arrayEchoes) as $aMostrar )
                    {
                        $arrayExpo[] = $aMostrar;
                    }
                    echo "Remitente:".$arrayExpo[0];
                    echo "<br>";
                    echo "Destinatario:".$arrayExpo[1];
                    echo "<br>";
                    echo "Mensaje:".$arrayExpo[2];
                }
            }
            else
            {
                echo "el usuario ".$emailObt." no recibio mensajes";
            }

        break;

        

        case "mensajes":

        $arrayExpoUsuario = $usuarioTXT->fileToArray();
        foreach($arrayExpoUsuario as $usuarioEXP)
        {
             $UsuarioAux[] = explode("-",$usuarioEXP);
        }

        $arrayExpoMensajes = $mensajesTXT->fileToArray();
        foreach($arrayExpoMensajes as $mensajeEXP)
        {
             $MensajeAux[] = explode("-",$mensajeEXP);
        }

        $arrayExpoMensFoto = $mensajesFotoTXT->fileToArray();
        foreach($arrayExpoMensFoto as $mensFotoEXP)
        {
             $MensjFotoAux[] = explode("-",$mensFotoEXP);
        }

        /*foreach($UsuarioAux as $usuarios)
        {
            $arrayUsuarios[] = $usuarios;
        }*/

        foreach($MensajeAux as $mensajes)
        {
            $arrayMensajes[] = $mensajes;
        }

        foreach($MensjFotoAux as $mensFoto)
        {
            $arrayMensFoto[] = $mensFoto;
        }

        foreach($UsuarioAux as $usuarios)
        {
            $arrayUsuarios[] = $usuarios;
            
        }



        break;
                   
        }
        
    }




?>