<?php

    class FotoMensaje
    {
        private $foto;
        private $remitente;
        private $destinatario;

        function __construct($foto,$remitente,$destinatario)
        {
            $this->foto = $foto;
            $this->remitente = $remitente;
            $this->destinatario = $destinatario;

            
            $ext = array_reverse(explode(".",$foto["name"]));
            $this->foto = $this->remitente."-".$this->destinatario."-"."Foto.".$ext[0];  
            move_uploaded_file($foto["tmp_name"],"./Img/".$this->foto);
        }

        public function __toString()
        {
            return $this->foto.PHP_EOL;
        }

        
        
    }






?>