<?php

    class Mensaje
    {
        private $remitente;
        private $destinatario;
        private $mensaje;

        function __construct($remitente,$destinatario,$mensaje)
        {
            $this->remitente = $remitente;
            $this->destinatario = $destinatario;
            $this->mensaje = $mensaje;
        }

        public function __toString()
        {
            return $this->remitente."-".$this->destinatario."-".$this->mensaje.PHP_EOL;
        }
        
    }






?>