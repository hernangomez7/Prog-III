<?php

    class Archivo
    {
        private $path;

        function __construct($path)
        {
            $this->path = $path;
        }

        

        public function Cargar($entidad)
        {
            $archivo = fopen($this->path ,"a");
            fwrite($archivo, $entidad );
            fclose($archivo);
        }


        public function Consultar($identificador,$cantidadCampos,$indiceIdentificador)
        { 
            $array = $this->fileToArray(); 
            $arrayRetorno = array();  
            foreach($array as  $i => $registro)
            {
                $arrayRegistro = explode("-",$registro);
                if(Count($arrayRegistro) == $cantidadCampos)
                {                    
                    if(trim($identificador) == trim($arrayRegistro[$indiceIdentificador]))
                    {
                        $arrayRetorno[] = $registro;
                    } 
                }    
            }
            return $arrayRetorno;
        }
        
        public function fileToArray()
        {
            $array = array();
            $archivo = fopen($this->path,"r");
            while(!feof($archivo))
            {
                $array[]=fgets($archivo);
            }   
            fclose($archivo);      
            return $array;
        }

        public function arrayToFile($array)
        {
            $archivo = fopen($this->path,"w");
            foreach($array as $registro)
            {
                fwrite($archivo,$registro);
            }            
            fclose($archivo);  
        } 
        
    

    
        public function Modificar($identificador,$indiceIdentificador,$cantidadCampos,$newEntity)
        {
            $array = $this->fileToArray();   
            foreach($array as  $i => $registro)
            {
                $arrayRegistro = explode("-",$registro);
                if(Count($arrayRegistro) == $cantidadCampos)
                {
                    if(trim($identificador) == trim($arrayRegistro[$indiceIdentificador]))
                    {
                        $array[$i] = $newEntity;
                        break;
                    } 
                }    
            }
            $this->arrayToFile($array);                       
        }

        public function backUp ($identificador,$indiceIdentificador,$cantidadCampos,$destinoOrigen,$indiceABackupear,$destinoBackUp)
        {
            $arrayRegistro = explode("-",$this->obtenerRegistro($identificador,$indiceIdentificador,$cantidadCampos));   
            $vadam = (string)$destinoOrigen."/".(string)$arrayRegistro[$indiceABackupear];
            rename( trim($vadam) , $destinoBackUp);            
        }
        public function obtenerRegistro($identificador,$indiceIdentificador,$cantidadCampos)
        {
            $array = $this->fileToArray();   
            foreach($array as  $i => $registro)
            {
                $arrayRegistro = explode("-",$registro);
                if(Count($arrayRegistro) == $cantidadCampos)
                { 
                    if(trim($identificador) == trim($arrayRegistro[$indiceIdentificador]))
                    {
                        return $registro;
                    } 
                }    
            }
            return null;
        }



    }

?>