<?php

    class Usuario
    {
        private $nombre;
        private $apellido;
        private $email;
        private $foto;

        function __construct($nombre,$apellido,$email,$foto)
        {
            $this->nombre = $nombre;
            $this->apellido = $apellido;
            $this->email = $email;
            $this->foto = $foto;
            
            $ext = array_reverse(explode(".",$foto["name"]));
            $this->foto = $this->email."_"."Foto.".$ext[0];  
            move_uploaded_file($foto["tmp_name"],"./Img/".$this->foto);
        }

        public function __toString()
        {
            return $this->nombre."-".$this->apellido."-".$this->email."-".$this->foto.PHP_EOL;
        }

        
        
    }






?>