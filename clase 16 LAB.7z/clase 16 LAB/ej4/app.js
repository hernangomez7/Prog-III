//marcar souceMap descomentar
//al export puedo utilizar lo que esta en el namespace
var unaMascota = new clases.Mascota(clases.Tipo["2"], 4, 1, "catDog", false);
unaMascota.AmputarExtremidades(2);
console.log(unaMascota);
console.log((unaMascota.patas));
