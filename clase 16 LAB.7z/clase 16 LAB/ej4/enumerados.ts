namespace clases
    {
    export enum Tipo
    {
        Ave,
        Perro,
        Gato,
        Reptil,
        Pez
    }
}