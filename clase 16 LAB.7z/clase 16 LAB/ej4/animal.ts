
/// <reference path="./enumerados.ts"/>
namespace clases
{
    export class Animal
    {
        public tipo:Tipo;
        public patas:number;
        protected edad:number;


        constructor(tipo:Tipo,patas:number, edad:number)
        {
            this.tipo = tipo;
            this.patas = patas;
            this.edad = edad;
        }

        Saludar():void
        {
            console.log(`Tengo ${this.patas} patas`);
        }

        protected AmputarExtremidad(cant:number):boolean
        {
            let todoOK:boolean = false;
            if(cant <= this.patas)
            {
                this.patas -= cant;
                todoOK = true;
            }
            return todoOK;
        }
    }
}