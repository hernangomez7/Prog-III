var clases;
(function (clases) {
    var Animal = /** @class */ (function () {
        function Animal(tipo, patas, edad) {
            this.tipo = tipo;
            this.patas = patas;
            this.edad = edad;
        }
        Animal.prototype.Saludar = function () {
            console.log("Tengo " + this.patas + " patas");
        };
        Animal.prototype.AmputarExtremidad = function (cant) {
            var todoOK = false;
            if (cant <= this.patas) {
                this.patas -= cant;
                todoOK = true;
            }
            return todoOK;
        };
        return Animal;
    }());
    clases.Animal = Animal;
})(clases || (clases = {}));
