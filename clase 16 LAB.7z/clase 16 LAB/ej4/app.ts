//marcar souceMap
//tsc --outFile o desmarcar en el tsconfig.json + el nombre del archivo de salida ej y los de entrada al final
//tsc --outFile app.js enumerados animal mascota app
/*
pero si tenemos muchos archivos debo hacerlo de otra forma
con tres barras  <reference path="mascota.ts"/> y mando por terminal
tsc --outFile app1.js app
 */

//al export puedo utilizar lo que esta en el namespace

/// <reference path="mascota.ts"/>
let unaMascota:clases.Mascota = new clases.Mascota(clases.Tipo["2"],4,1,"catDog",false);

unaMascota.AmputarExtremidades(2);

console.log(unaMascota);
console.log((unaMascota.patas));




 



