$(document).ready(function{
    $("#miH1").text("Nos vamos al infierno");
})