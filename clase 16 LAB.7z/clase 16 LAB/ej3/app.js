var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var clases;
(function (clases) {
    var Tipo;
    (function (Tipo) {
        Tipo[Tipo["Ave"] = 0] = "Ave";
        Tipo[Tipo["Perro"] = 1] = "Perro";
        Tipo[Tipo["Gato"] = 2] = "Gato";
        Tipo[Tipo["Reptil"] = 3] = "Reptil";
        Tipo[Tipo["Pez"] = 4] = "Pez";
    })(Tipo = clases.Tipo || (clases.Tipo = {}));
    var Animal = /** @class */ (function () {
        function Animal(tipo, patas, edad) {
            this.tipo = tipo;
            this.patas = patas;
            this.edad = edad;
        }
        Animal.prototype.Saludar = function () {
            console.log("Tengo " + this.patas + " patas");
        };
        Animal.prototype.AmputarExtremidad = function (cant) {
            var todoOK = false;
            if (cant <= this.patas) {
                this.patas -= cant;
                todoOK = true;
            }
            return todoOK;
        };
        return Animal;
    }());
    clases.Animal = Animal;
    var Mascota = /** @class */ (function (_super) {
        __extends(Mascota, _super);
        function Mascota(tipo, patas, edad, nombre, comio) {
            var _this = _super.call(this, tipo, patas, edad) || this;
            _this.nombre = nombre;
            _this.comio = comio;
            return _this;
            //this.edad ACCede porque es protected
        }
        Object.defineProperty(Mascota.prototype, "Edad", {
            get: function () {
                return this.edad;
            },
            set: function (v) {
                this.edad = v;
            },
            enumerable: true,
            configurable: true
        });
        //llamo a la funcion del padre para poder usarla
        Mascota.prototype.AmputarExtremidades = function (cant) {
            return this.AmputarExtremidad(cant);
        };
        return Mascota;
    }(Animal));
    clases.Mascota = Mascota;
})(clases || (clases = {}));
//al export puedo utilizar lo que esta en el namespace
var unaMascota = new clases.Mascota(clases.Tipo["2"], 4, 1, "catDog", false);
unaMascota.AmputarExtremidades(2);
console.log(unaMascota);
console.log((unaMascota.patas));
