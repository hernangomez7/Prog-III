namespace clases
{

    export enum Tipo{
        Ave,
        Perro,
        Gato,
        Reptil,
        Pez
    }

    export class Animal
    {
        public tipo:Tipo;
        public patas:number;
        protected edad:number;


        constructor(tipo:Tipo,patas:number, edad:number)
        {
            this.tipo = tipo;
            this.patas = patas;
            this.edad = edad;
        }

        Saludar():void
        {
            console.log(`Tengo ${this.patas} patas`);
        }

        protected AmputarExtremidad(cant:number):boolean
        {
            let todoOK:boolean = false;
            if(cant <= this.patas)
            {
                this.patas -= cant;
                todoOK = true;
            }
            return todoOK;
        }
    }

    export class Mascota extends Animal{
        nombre:string;
        comio:boolean;

        constructor(tipo:Tipo,patas:number, edad:number,nombre:string,comio:boolean )
        {
            super(tipo,patas, edad);
            this.nombre = nombre;
            this.comio = comio;
            //this.edad ACCede porque es protected
        }

        public set Edad(v: number)
        {
            this.edad = v;
        }

        public get Edad() : number
        {
            return this.edad;
        }

        //llamo a la funcion del padre para poder usarla
        AmputarExtremidades(cant:number):boolean
        {
            return this.AmputarExtremidad(cant);
        }

    }
}

//al export puedo utilizar lo que esta en el namespace
let unaMascota:clases.Mascota = new clases.Mascota(clases.Tipo["2"],4,1,"catDog",false);

unaMascota.AmputarExtremidades(2);

console.log(unaMascota);
console.log((unaMascota.patas));




 



