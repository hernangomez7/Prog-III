var Tipo;
(function (Tipo) {
    Tipo[Tipo["Ave"] = 0] = "Ave";
    Tipo[Tipo["Perro"] = 1] = "Perro";
    Tipo[Tipo["Gato"] = 2] = "Gato";
    Tipo[Tipo["Reptil"] = 3] = "Reptil";
    Tipo[Tipo["Pez"] = 4] = "Pez";
})(Tipo || (Tipo = {}));
/*
primer ver. falta inicializar el tipo
class Animal{
    tipo:Tipo;
    patas:number;
    edad:number;

    constructor(){

    }
}
*/
/*
class Animal{
    tipo:Tipo = Tipo.Ave;
    patas:number;
    edad:number;

    constructor(){

    }
}
*/
var Animal = /** @class */ (function () {
    /*
        constructor(tipo:Tipo,patas:number, edad:number)
        {
            this.tipo = tipo;
            this.patas = patas;
            this.edad = edad;
        }*/
    /*
    //edad es opcional
    constructor(tipo:Tipo,patas:number, edad?:number)
    {
        this.tipo = tipo;
        this.patas = patas;
        //this.edad = edad;
        if(edad)
        {
            this.edad = edad;
        }
    }*/
    //default
    function Animal(tipo, patas, edad) {
        if (edad === void 0) { edad = 3; }
        this.tipo = tipo;
        this.patas = patas;
        this.edad = edad;
    }
    Animal.prototype.Saludar = function () {
        console.log("Tengo " + this.patas + " patas");
    };
    Animal.comio = false;
    return Animal;
}());
//let unaMascota:Animal = new Animal(Tipo["1"],4,7);
var unaMascota = new Animal(Tipo["1"], 4); //sin edad
//unaMascota.tipo no aparecera los datos private, aunque al transpilar esto no aparecera por que, en js no existe esto
//console.log(unaMascota);
console.log(unaMascota);
unaMascota.Saludar();
//console.log(Animal.comio);
