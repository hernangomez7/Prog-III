enum Tipo{
    Ave,
    Perro,
    Gato,
    Reptil,
    Pez
}
/*
primer ver. falta inicializar el tipo
class Animal{
    tipo:Tipo;
    patas:number;
    edad:number;

    constructor(){

    }
}
*/
/*
class Animal{
    tipo:Tipo = Tipo.Ave;
    patas:number;
    edad:number;

    constructor(){

    }
}
*/

class Animal{
    public tipo:Tipo;
    private patas:number;
    public edad:number;

    static comio:boolean = false;
/*
    constructor(tipo:Tipo,patas:number, edad:number)
    {
        this.tipo = tipo;
        this.patas = patas;
        this.edad = edad;
    }*/
    /*
    //edad es opcional
    constructor(tipo:Tipo,patas:number, edad?:number)
    {
        this.tipo = tipo;
        this.patas = patas;
        //this.edad = edad;
        if(edad)
        {
            this.edad = edad;
        }
    }*/
    //default
    constructor(tipo:Tipo,patas:number, edad:number = 3)
    {
        this.tipo = tipo;
        this.patas = patas;
        this.edad = edad;
    }

    Saludar():void
    {
        console.log(`Tengo ${this.patas} patas`);
    }
}
//let unaMascota:Animal = new Animal(Tipo["1"],4,7);
let unaMascota:Animal = new Animal(Tipo["1"],4);//sin edad

//unaMascota.tipo no aparecera los datos private, aunque al transpilar esto no aparecera por que, en js no existe esto
//console.log(unaMascota);

console.log(unaMascota);

unaMascota.Saludar();

//console.log(Animal.comio);



