var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
//usamos extenciones
var Tipo;
(function (Tipo) {
    Tipo[Tipo["Ave"] = 0] = "Ave";
    Tipo[Tipo["Perro"] = 1] = "Perro";
    Tipo[Tipo["Gato"] = 2] = "Gato";
    Tipo[Tipo["Reptil"] = 3] = "Reptil";
    Tipo[Tipo["Pez"] = 4] = "Pez";
})(Tipo || (Tipo = {}));
var Animal = /** @class */ (function () {
    //static comio:boolean = false;
    function Animal(tipo, patas, edad) {
        this.tipo = tipo;
        this.patas = patas;
        this.edad = edad;
    }
    Animal.prototype.Saludar = function () {
        console.log("Tengo " + this.patas + " patas");
    };
    Animal.prototype.AmputarExtremidad = function (cant) {
        var todoOK = false;
        if (cant <= this.patas) {
            this.patas -= cant;
            todoOK = true;
        }
        return todoOK;
    };
    return Animal;
}());
var Mascota = /** @class */ (function (_super) {
    __extends(Mascota, _super);
    function Mascota(tipo, patas, edad, nombre, comio) {
        var _this = _super.call(this, tipo, patas, edad) || this;
        _this.nombre = nombre;
        _this.comio = comio;
        return _this;
        //this.edad ACCede porque es protected
    }
    Object.defineProperty(Mascota.prototype, "Edad", {
        get: function () {
            return this.edad;
        },
        set: function (v) {
            this.edad = v;
        },
        enumerable: true,
        configurable: true
    });
    //llamo a la funcion del padre para poder usarla
    Mascota.prototype.AmputarExtremidades = function (cant) {
        return this.AmputarExtremidad(cant);
    };
    return Mascota;
}(Animal));
var unaMascota = new Mascota(Tipo["2"], 4, 1, "catDog", false);
//unaMascota.Edad = 45; set edad
//console.log(unaMascota.Edad); get edad
//amputarextremidad
unaMascota.AmputarExtremidades(1);
console.log(unaMascota);
console.log((unaMascota.patas));
