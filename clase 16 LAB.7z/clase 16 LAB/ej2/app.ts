//usamos extenciones
enum Tipo{
    Ave,
    Perro,
    Gato,
    Reptil,
    Pez
}

class Animal
{
    public tipo:Tipo;
    public patas:number;
    protected edad:number;

    //static comio:boolean = false;

    constructor(tipo:Tipo,patas:number, edad:number)
    {
        this.tipo = tipo;
        this.patas = patas;
        this.edad = edad;
    }

    Saludar():void
    {
        console.log(`Tengo ${this.patas} patas`);
    }

    protected AmputarExtremidad(cant:number):boolean
    {
        let todoOK:boolean = false;
        if(cant <= this.patas)
        {
            this.patas -= cant;
            todoOK = true;
        }
        return todoOK;
    }
}

class Mascota extends Animal{
    nombre:string;
    comio:boolean;

    constructor(tipo:Tipo,patas:number, edad:number,nombre:string,comio:boolean )
    {
        super(tipo,patas, edad);
        this.nombre = nombre;
        this.comio = comio;
        //this.edad ACCede porque es protected
    }

    public set Edad(v: number)
    {
        this.edad = v;
    }

    public get Edad() : number
    {
        return this.edad;
    }

    //llamo a la funcion del padre para poder usarla
    AmputarExtremidades(cant:number):boolean
    {
        return this.AmputarExtremidad(cant);
    }

}

let unaMascota:Mascota = new Mascota(Tipo["2"],4,1,"catDog",false);

//unaMascota.Edad = 45; set edad
//console.log(unaMascota.Edad); get edad

//amputarextremidad
unaMascota.AmputarExtremidades(1);

console.log(unaMascota);
console.log((unaMascota.patas));




 



