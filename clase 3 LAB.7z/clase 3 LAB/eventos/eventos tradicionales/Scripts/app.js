//Metodo Tradicional: actualmente en desuso
//esto ahora titulo es un objeto, por lo tanto 'titulo.onclick = salud;' le agrega el accionador
//lo que le paso es un puntero de la funcion: saludar
//titulo.onclick = saludar;


//Window.onload = inicializarEventos;

/*function inicializarEventos()
{
    //se le agrega el manejador
    document.getElementById("titulo").onclick = saludar;

}*/
//le asigno una funcion 
/*
window.onload = function()
{
    //se le agrega el manejador
    document.getElementById("titulo").onclick = saludar;

}


function saludar()
{
    //esto se ejecutara primero,luego lo otro
    alert("estoy adentro de la funcion cambiar");
    
    titulo.innerHTML = "Nuevo titulo";

}*/

//esta es la forma correcta de hacerlo
window.onload = function()
{
    //addEventListener: permite invorcar diferentes eventos, a diferencia de onload
    this.document.getElementById("titulo").addEventListener("click",saludar,false);
    //le agrego otro manejador
    this.document.getElementById("titulo").addEventListener("mouseover",cambiarColor,false);
    //
    this.document.getElementById("titulo").addEventListener("click",cambiartexto,false);
    this.document.getElementById("titulo").addEventListener("click",function()
    {
        alert("ultimo manejador");
    }    
    ,false);


}

function saludar()
{
    //esto se ejecutara primero,luego lo otro
    alert("estoy adentro de la funcion cambiar");
    
    titulo.innerHTML = "Nuevo titulo";
    document.getElementById("titulo").removeEventListener("click",saludar);

}

function cambiarColor()
{
    document.getElementById("titulo").style.color = "red";
}

function cambiartexto ()
 {
    document.getElementById("titulo").innerHTML = "Otro cambio de texto";
 }