<?php

	//referencia por q un archivo es muy imprtante
	//al poner _once evitar definirla muchas veces que da problemas
	include_once "funciones.php";
	//include correra con errores

	//referencia por q un archivo NO es muy imprtante
	//require "funciones.php";
	//con require no correra si no lo encuentra

	include_once "Alumno.php";

	//imprimier mensaje
	echo "Hello World! <br>";
	//escribir en php para html
	echo "<h1> hola </h1> ";

	//crear variable
	$Nombre = "MyNameIs <br>";
	$Space = " ";
	$Apellido = "Unknow <br>";
	//impresion de variable
	echo $Nombre;
	//concatenar
	echo $Nombre.$Apellido;
	//concatenar 2
	echo "Hola $Apellido";

	echo sumarNumeros(1,2)."<br>";
	sumarNumeros2(1,2);
	//muestra lo que dato es la varieble, que tipo era
	var_dump($Nombre);
	echo "<br>";
	var_dump(sumarNumeros(1,2));
	//ARRAY

	$array = ARRAY(10,20);

	//var_dump($array)

	foreach ($array as $elementos) 
	{
		echo $elementos;
	}
	echo "<br>";


	$clave = ARRAY("alfa" => 666, "beta" => 555, "gamma" => 444);

	$clave["otro"] = "algo";

	var_dump($clave);

	echo "<br>";
	foreach ($clave as $key => $value)
	{
		echo "<br>";
		echo $key;
	}

	//var_dump($queEsEsto = []);
	//var_dump($yesto ={});
	$obj = new stdclass;
	echo "<br>";
	var_dump($obj);
	echo "<br>";
	//es un objeto dinamico, sele puede adicionar de forma dinamica
	$obj->Nombre = "MyNameIs"."<br>";

	var_dump($obj);

	//PHP en servidor es un gran texto pra usarlo se debe cargar

	echo "<br>";
	//crear toma de la clase la funcion estatica
	echo Alumno::saludar()."<br>";

	$alumno = new Alumno();
	//este llama la funcion pese a tener instancia $alumno
	echo $alumno->saludar()."<br>";

	//$alumno->Lejago = "sapato";

	$alumno->Lejago = 4141;

	$alumno->cargarLegajo(4000)

	//echo $alumno->Lejago;

	//echo $alumno->Lejago;



?>