<?php
	//clase de prueba
	class Alumno 
	{
		public $Lejago;
		static function saludar()
		{
			return "hola";
		}

		public function cargarLegajo($value)
		{
			$this->Lejago = $value;
		}
	}
?>