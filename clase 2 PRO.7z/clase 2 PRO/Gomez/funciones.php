<?php

function sumarNumeros($valor,$valor2)
{
   $resultado = $valor + $valor2;

   return $resultado;
   //echo " $resultado <br>";
}

function sumarNumeros2($valor,$valor2)
{
   $resultado = $valor + $valor2;

   echo "$resultado <br>";
}

?>