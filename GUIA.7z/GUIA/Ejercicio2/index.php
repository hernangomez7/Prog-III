<?php

	function sumarDosNumero($value1,$value2)
	{
		$variable = $value1 + $value2;

		echo $variable;
	}
	

	sumarDosNumero(1,2);



?>