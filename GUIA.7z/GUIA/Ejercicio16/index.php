<?php

	function invertidorArray($Palabra)
	{
		$arraySalida = array();
		//echo count($Palabra);
		for($i = count($Palabra);$i > 0 ;$i--)
		{
			$arraySalida[] = $Palabra[$i];
		}
		return $arraySalida;
	}

	$Palabra = array("H","O","L","A");

	//$Palabra = "hola";

	//echo implode(invertidorArray($Palabra),",");
	invertidorArray($Palabra);

	//var_dump(implode($Palabra,"")); sale string

?>