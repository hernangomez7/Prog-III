<?php

	//Aplicación Nº 1 (Mostrar variables)
	//Realizar un programa que guarde su nombre en $nombre y su apellido en $apellido . Luego
	//mostrar el contenido de las variables con el siguiente formato: Pérez, Juan. Utilizar el operador
	//de concatenación.
	
	$variable1 = "nombre";
	$variable2 = "apellido";

	$variable3 = $variable1.",".$variable2.".";

	echo $variable3;

?>