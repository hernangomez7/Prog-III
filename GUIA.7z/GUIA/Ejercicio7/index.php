<?php

	function sumarAcumular()
	{
		echo date("d/m/y");
	}
	sumarAcumular();

?>