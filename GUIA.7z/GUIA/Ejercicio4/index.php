<?php

	function sumarAcumular($value1,$value2)
	{
		$Acumulador = 0;
		$sumador = 1;
		$myArray = ARRAY();

		//adiciona
		//$myArray[]= 1;
		//$myArray[]= 8;
		
		while($Acumulador < 1001)
		{
			$Acumulador += $sumador;
			$myArray []= $sumador;
			$sumador += 1;
		}

		foreach ($myArray as $key) 
		{
			echo $key."<br>";
		}
		//count.($myArray)
		//var_dump($myArray); 
	}
	

	sumarAcumular(1,2);

?>