<?php

	function sumarDosNumero($value1,$value2)
	{
		$variable = $value1 + $value2;

		return $variable;
	}
	
	echo "Resultado:"."<br>";

	$resultado = sumarDosNumero(1,2);

	echo $resultado;



?>