<?php

	function potencia()
	{
		$sumador = 1;

		for($i = 0;$i <= 4;$i++)
		{
			echo (pow($sumador , $i)."<br>");
			$sumador += 1;
		}
	}

	potencia();

?>