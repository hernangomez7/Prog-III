var genericoArray = [1,2,6,4,5,3];


window.addEventListener('load', inicializarEventos, false);

function inicializarEventos()
{
    ///document.getElementById('btnCargar').addEventListener('click',traerTexto, false);
    var num = arrayCuadrado(genericoArray);
    console.log(num);
}

function arrayCuadrado(array)
{
    var retorno;
    for(var i=0;i<array.leght;i++)
    {
        retorno[i] = Math.pow(array[i],2); 
    }
    return retorno;
}

function mostrarArray(array)
{
    array.forEach(element => {
        console.log(element);
    });
}


/*
callback: pasar una funcion a otra funcion que utilizara mas adelante
map: aplica una funcion a un array, ambos dtos como parametros retorna array
filter: filtra array a travez de una funcion que devuelve true o false retorna array
reduce: recibe dos parametros un callback y un valor inicial(opcional), retorna un unico valor u objeto





*/