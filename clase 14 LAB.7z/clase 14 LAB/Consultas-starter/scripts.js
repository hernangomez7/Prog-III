//console.log(data);

/*
    realizar las operaciones usando los metodos map,  reduce y filter y combinaciones entre ellos
  */


var soluciones = {};

// Retornar un array con los nombres de los usuarios femeninos

soluciones.usuariosFemeninos = function(usuarios){
    return usuarios
    .filter(function(user){
        return user.genero === 'Female';
    })
    .map(function(user){
        return user.nombre;
    });
}

//console.log(soluciones.usuariosFemeninos(data));

// Retornar un array de strings (el email de los usuarios de sexo masculino)

soluciones.mailsVarones = function(usuarios){
    return usuarios
    .filter(function(user){
        return user.genero === 'Male';
    })
    .map(function(user){
        return user.email;
    });
}

//console.log(soluciones.mailsVarones(data));

// Retornar un array de objetos que solo contengan las claves nombre, email y edad, de todos los usuarios mayores que 'edad'

soluciones.usuariosMayores = function(usuarios, edad){
    return usuarios
    .filter(function(user){
        return user.edad > edad;
    })
    .map(function(user){
        clave = {
            nombre: user.nombre,
            email: user.email,
            edad: user.edad,
        }
        return clave;
    });
    
}

//console.log(soluciones.usuariosMayores(data, 40));

  // Retornar un objeto que contenga solo el nombre y la edad del usuario mas grande.

soluciones.usuarioMasGrande = function(usuarios){
    return usuarios
    .reduce( function (previo, actual) {

        if( previo.edad > actual.edad)
        {
            return previo;
        }else
        {
            return actual;
        }
       
    }, 0).nombre;    
}

//console.log(soluciones.usuarioMasGrande(data));

// Retornar el promedio de edad de los usuarios (number)

soluciones.promedio = function(usuarios)
{
    return usuarios
    .map(function(usuario){
        return usuario.edad;
    })
    .reduce(function(previo, actual){
        return previo + actual;
    })/(usuarios.length);   
}

//console.log("Promedio edad usuarios " + soluciones.promedio(data));

// Retornar el promedio de edad de los usuarios hombres (number)

soluciones.promedioVarones = function(usuarios){
    return soluciones.promedio(usuarios
        .filter(function(user){
            return user.genero === 'Male';
        })
        );

    /*
    var varones = usuarios.filter(function(user){
        return user.genero === 'Male';
    });

    return soluciones.promedio(varones);*/

    /*
    return promedio(usuarios
    .filter(function(user){
        return user.genero === 'Male';
    })
    );*/
}

//console.log("Promedio edad Varones " + soluciones.promedioVarones(data));

 // Retornar el promedio de edad de los usuarios mujeres (number)

soluciones.promedioMujeres = function(usuarios){
    return soluciones.promedio(usuarios
        .filter(function(user){
            return user.genero === 'Female';
        })
        );
   
}

//console.log("Promedio edad Mujeres " + soluciones.promedioMujeres(data));

    //mission accomplished
/*
boostrap : getBoostrap.com es framework como jquery se puede descargar con el bower

!!!los scr se ponen abajo en el body por alguna razon!!!
en extenciones se puede encotrar ext

TERMINAL:1)en carpte de index bower init
instalar con bower bower instal boostrap 4 --6
el --6 es para que lo aqgrege en el bower.json
en bower component esta el boostrap y sus dependencias
href:bower/component////...
con el "bower install" instala todas las dependencia del bower,(como una lista de mercado esta en el boweer.json)

en boostrap debe estar todo en un div tipo class="container" y todo lo que este adentro estara afectado por boostrap(examp escribir algo y que este modificado)
nunca modificar nada del css del boostrap para "písar" se pone despues el css

dentro del <div class="row"
            <div class="col color1" >UNO</div>
            <div class="col color2">DOS</div>
            <div class="col color3">DOS</div>
            <div class="col ">TRES</div>
            /div>


(los color se encuentra en el ccs creado en el momento)            
con la extencio window.resize de puede cambiar los tamaños para probar
con f12 con el toolbar se puede modificar el tamaño simulando dispositivos


->son tamaños para que puedan ser response(cambiar segun el tamaño)
col     <576
col xs <576
col sm
col -mm <768
col lg <990
col xl <1200
<-
class'col-md-3'
los valores de las columnas deben tener un valor tal que la suma de todos no supere 12
siendo 3columnas 4 entonces la pagina se divide en partes iguales
si se supera este valor se colapsa(uno arriva de otro)
con offset se desplezan
con container queda centrado
y con container fluid que centrado y ocupa tdo

(para crear multiples objetos se hace una referencia mas * ,examp h2*4)
(tr*3>td*3)

a las tabla se le pone class "table" y lo modifica

*/